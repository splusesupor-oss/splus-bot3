import asyncio
from main import SoroushAntiSpamBot

async def main():
    bot = SoroushAntiSpamBot()
    await bot.initialize_client()
    await bot.client.connect()

    group = None

    async for dialog in bot.client.iter_dialogs():
        if getattr(dialog.entity, "id", None) == 9429374:
            group = dialog.entity
            break

    print("GROUP:", group.title)

    try:
        admins = await bot.client.get_participants(
            group,
            filter="admins"
        )

        print("ADMIN COUNT:", len(admins))

        for a in admins:
            print(a.id, getattr(a, "username", None), getattr(a, "first_name", None))

    except Exception as e:
        print("ERROR:", e)

    await bot.client.disconnect()

asyncio.run(main())
