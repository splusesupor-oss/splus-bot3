from pathlib import Path

p = Path("main.py")
lines = p.read_text(encoding="utf-8").splitlines()

indent = lines[265][:len(lines[265]) - len(lines[265].lstrip())]

lines[266] = indent + "asyncio.create_task(self.riddle_timeout_reply(event, chat_id, user_id))"

p.write_text("\n".join(lines) + "\n", encoding="utf-8")
print("✅ فاصله خط 267 از خط 266 کپی شد")
