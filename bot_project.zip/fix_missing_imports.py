file="handlers/message_handler.py"

with open(file,encoding="utf8") as f:
    data=f.read()

imports=[
"from modules.jorat_haghighat import get_jorat, get_haghighat",
"from modules.font_converter import make_fonts",
"from modules.group_stats import make_report"
]

add=[]

for i in imports:
    if i not in data:
        add.append(i)

if add:
    data="\n".join(add)+"\n"+data
    with open(file,"w",encoding="utf8") as f:
        f.write(data)
    print("FIXED:",add)
else:
    print("Already OK")
